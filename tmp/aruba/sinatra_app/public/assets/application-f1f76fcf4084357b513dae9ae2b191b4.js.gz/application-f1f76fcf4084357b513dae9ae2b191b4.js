(function() {
  console.log('Goodbye');
}).call(this);
(function() {
  console.log('Hello');
}).call(this);
